// src/pages/Products.jsx
import ProductList from "../components/ProductList";

export default function Products() {
  return (
    <div className="pt-8">
      <ProductList />
    </div>
  );
}
