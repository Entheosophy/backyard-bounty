// src/components/ProductList.jsx
import { useState } from "react";
import HeatScale from "./HeatScale";
import ProductModal from "./ProductModal";

const products = [
  {
    name: "Heirloom Mild",
    description: "Bright and fresh with just a spark of warmth.",
    heatLevel: 1,
    ingredients: ["Tomatoes", "Bell Peppers", "Garlic", "Onion", "Salt"],
    nutrition: "20 cal / 2 tbsp"
  },
  {
    name: "Original Medium",
    description: "Balanced jalapeño kick and garden sweetness.",
    heatLevel: 2,
    ingredients: ["Tomatoes", "Jalapeños", "Onion", "Garlic", "Salt"],
    nutrition: "25 cal / 2 tbsp"
  },
  {
    name: "Fire-Roasted Hot",
    description: "Serrano heat with deep, smoky undertones.",
    heatLevel: 3,
    ingredients: ["Fire-roasted Tomatoes", "Serrano Peppers", "Garlic", "Smoked Paprika"],
    nutrition: "30 cal / 2 tbsp"
  }
];

export default function ProductList() {
  const [selected, setSelected] = useState(null);

  return (
    <section className="max-w-4xl mx-auto px-6 py-8">
      <h2 className="text-2xl font-semibold mb-4 text-center">Salsa Flavors</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {products.map((product, i) => (
          <button
            key={i}
            onClick={() => setSelected(product)}
            className="border p-4 shadow-sm rounded bg-white/10 backdrop-blur-md text-left transition hover:scale-[1.01] hover:shadow-md"
          >
            <h3 className="font-bold text-lg mb-2 text-[var(--scene-text)]">{product.name}</h3>
            <p className="text-sm text-[var(--scene-text)] opacity-80 mb-4">
              {product.description}
            </p>
            <HeatScale heatLevel={product.heatLevel} />
          </button>
        ))}
      </div>
      <ProductModal product={selected} onClose={() => setSelected(null)} />
    </section>
  );
}
