// src/components/ProductModal.jsx

import { useEffect } from "react";
import { useBasket } from "../context/BasketContext";
import { toast } from "react-hot-toast";

export default function ProductModal({ product, onClose }) {
  const { addItem } = useBasket(); // ✅ FIXED: Correct function name

  useEffect(() => {
    const handleKey = (e) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handleKey);
    return () => document.removeEventListener("keydown", handleKey);
  }, [onClose]);

  const handleBackdrop = (e) => {
    if (e.target === e.currentTarget) onClose();
  };

  const handleAdd = () => {
    if (!product || !addItem) return;
    addItem(product, 1); // ✅ Correct call
    toast.success(`${product.name} added to basket`);
    onClose();
  };

  if (!product) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm px-4"
      onClick={handleBackdrop}
    >
      <div className="relative bg-[var(--scene-bg)] text-[var(--scene-text)] rounded-lg shadow-lg max-w-md w-full p-6 space-y-4">
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Close"
          className="absolute top-3 right-3 text-xl font-bold opacity-50 hover:opacity-100 transition text-[var(--scene-text)]"
        >
          &times;
        </button>

        <h3 className="text-xl font-bold">{product.name}</h3>
        <p className="text-sm opacity-80">{product.description}</p>

        <ul className="text-sm list-disc list-inside">
          {product.ingredients.map((item, i) => (
            <li key={i}>{item}</li>
          ))}
        </ul>

        <div className="text-sm border-t pt-3 opacity-70">
          <strong>Nutrition:</strong> {product.nutrition}
        </div>

        <button
          className="mt-4 w-full px-4 py-2 rounded bg-amber-500 hover:bg-amber-600 text-white font-semibold"
          onClick={handleAdd}
        >
          Add to Basket
        </button>
      </div>
    </div>
  );
}
