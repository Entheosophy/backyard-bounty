// src/components/NightSky.jsx
import { useEffect, useState } from "react";

export default function NightSky() {
  const [stars, setStars] = useState([]);

  useEffect(() => {
    const newStars = Array.from({ length: 100 }, () => ({
      top: `${Math.random() * 55}%`, // stars only ABOVE the hills
      left: `${Math.random() * 100}%`,
      size: Math.random() * 1.5 + 0.5,
      delay: Math.random() * 5,
    }));
    setStars(newStars);
  }, []);

  return (
    <div className="absolute inset-0 z-[-1] pointer-events-none">
      {/* Sky gradient */}
      <div className="absolute inset-0 theme-night:opacity-100 opacity-0 transition-opacity duration-700 bg-gradient-to-b from-black via-indigo-900 to-violet-950" />

      {/* Stars (in sky only) */}
      {stars.map((star, i) => (
        <div
          key={i}
          className="absolute rounded-full bg-white opacity-70 animate-twinkle theme-night:opacity-100 opacity-0 transition-opacity duration-700"
          style={{
            top: star.top,
            left: star.left,
            width: `${star.size}px`,
            height: `${star.size}px`,
            animationDelay: `${star.delay}s`,
          }}
        />
      ))}

      <style>{`
        @keyframes twinkle {
          0%, 100% { opacity: 0.3; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.2); }
        }
        .animate-twinkle {
          animation: twinkle 3s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}
