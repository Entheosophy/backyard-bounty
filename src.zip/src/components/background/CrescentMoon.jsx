// src/components/CrescentMoon.jsx
import { forwardRef } from "react";

const CrescentMoon = forwardRef(function CrescentMoon(_, ref) {
  return (
    <div
      ref={ref}
      // Apply fixed positioning directly to the moon container
      // Center it horizontally with left-1/2 and -translate-x-1/2
      // Set a desired top position
      className="fixed top-[60px] left-1/2 -translate-x-1/2 w-[160px] h-[160px] z-0 transition-opacity duration-500 theme-day:opacity-0 theme-night:opacity-100"
    >
      {/* Full moon base */}
      <div className="w-full h-full rounded-full bg-[var(--scene-sun)] opacity-50 blur-xl absolute" />
      {/* Visible crescent */}
      <div className="w-full h-full rounded-full bg-[#e0e7ff] shadow-md relative overflow-hidden">
        {/* This div creates the 'bite' for the crescent. Use --scene-bg for theme compliance. */}
        <div className="absolute -left-1/4 top-0 w-full h-full rounded-full bg-[var(--scene-bg)]" />
      </div>
    </div>
  );
});

export default CrescentMoon;