// src/components/background/DayNightInsects.jsx
import { useEffect, useState } from "react";

export default function DayNightInsects() {
  const [isNight, setIsNight] = useState(false);

  useEffect(() => {
    const update = () =>
      setIsNight(document.documentElement.classList.contains("theme-night"));
    update();
    const observer = new MutationObserver(update);
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["class"],
    });
    return () => observer.disconnect();
  }, []);

  const bees = [
    { id: 1, top: "20%", left: "10%", delay: 0 },
    { id: 2, top: "35%", left: "70%", delay: 1 },
    { id: 3, top: "50%", left: "30%", delay: 2 },
  ];

  const fireflies = Array.from({ length: 60 }, (_, i) => ({
    id: i,
    top: `${Math.random() * 80 + 10}%`,
    left: `${Math.random() * 100}%`,
    size: Math.random() * 2 + 1,
    color: "#facc15",
    delay: Math.random() * 5,
    duration: Math.random() * 10 + 5,
  }));

  return (
    <div className="absolute inset-0 z-[-1] pointer-events-none">
      {/* Fireflies (night) */}
      <div className={`absolute inset-0 transition-opacity duration-700 ${isNight ? "opacity-100" : "opacity-0"}`}>
        {fireflies.map((bug) => (
          <div
            key={bug.id}
            className="absolute rounded-full animate-float"
            style={{
              top: bug.top,
              left: bug.left,
              width: `${bug.size}px`,
              height: `${bug.size}px`,
              backgroundColor: bug.color,
              opacity: 0.8,
              filter: "blur(0.5px)",
              animationDelay: `${bug.delay}s`,
              animationDuration: `${bug.duration}s`,
            }}
          />
        ))}
      </div>

      {/* Bees (day) */}
      <div className={`absolute inset-0 transition-opacity duration-700 ${isNight ? "opacity-0" : "opacity-100"}`}>
        {bees.map((bee) => (
          <div
            key={bee.id}
            className="absolute animate-[buzz_4s_linear_infinite] pointer-events-auto transition-transform hover:scale-125"
            style={{ top: bee.top, left: bee.left, animationDelay: `${bee.delay}s` }}
          >
            <svg viewBox="0 0 32 32" width="24" height="24" fill="gold" className="drop-shadow-sm">
              <circle cx="16" cy="16" r="6" fill="#facc15" stroke="#92400e" strokeWidth="1" />
              <ellipse cx="12" cy="12" rx="2" ry="4" fill="#fff" opacity="0.8" />
              <ellipse cx="20" cy="12" rx="2" ry="4" fill="#fff" opacity="0.8" />
            </svg>
          </div>
        ))}
      </div>

      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0) translateX(0); opacity: 0.7; }
          50% { transform: translateY(-10px) translateX(5px); opacity: 1; }
        }
        .animate-float {
          animation: float ease-in-out infinite;
        }
        @keyframes buzz {
          0%, 100% { transform: translate(0, 0); }
          25% { transform: translate(2px, -2px); }
          50% { transform: translate(-2px, 2px); }
          75% { transform: translate(1px, -1px); }
        }
      `}</style>
    </div>
  );
}
