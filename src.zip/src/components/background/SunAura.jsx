// src/components/background/SunAura.jsx
import { forwardRef } from "react";

const SunAura = forwardRef(function SunAura(_, ref) {
  return (
    <div
      ref={ref}
      className="fixed top-[120px] left-1/2 -translate-x-1/2 w-[220px] h-[220px] rounded-full blur-3xl opacity-60 bg-[var(--scene-sun)] z-[-1] pointer-events-none transition-opacity duration-700 theme-day:opacity-60 theme-night:opacity-0"
    />
  );
});

export default SunAura;
